let token = "";

// LOGIN
async function login() {
    try {
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        const res = await fetch("http://localhost:3000/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();
        console.log("DATA:", data);


        if (data.token) {
            token = data.token;

            // Ocultar login y mostrar tareas
            document.getElementById("login-section").style.display = "none";
            document.getElementById("task-section").style.display = "block";

            getTasks();
        } else {
            alert("Email o contraseña incorrectos");
        }

    } catch (error) {
        console.error("Error en login:", error);
        alert("Error al intentar iniciar sesión");
    }
}

// CREAR TAREA
async function createTask() {
    try {
        const title = document.getElementById("title").value;
        const description = document.getElementById("description").value;
        const due_date = document.getElementById("due_date").value;

        await fetch("http://localhost:3000/api/tasks", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify({ title, description, due_date })
        });

        getTasks();
    } catch (error) {
        console.error("Error al crear tarea:", error);
    }
}

// OBTENER TAREAS
async function getTasks() {
    try {
        const res = await fetch("http://localhost:3000/api/tasks", {
            headers: { "Authorization": "Bearer " + token }
        });

        const tasks = await res.json();
        const list = document.getElementById("task-list");
        list.innerHTML = "";

        tasks.forEach(task => {
            const li = document.createElement("li");
            li.innerHTML = `
                <strong>${task.title}</strong><br>
                ${task.description}<br>
                Estado: ${task.status}<br>
                <button onclick="deleteTask('${task._id}')">Eliminar</button>
            `;
            list.appendChild(li);
        });

    } catch (error) {
        console.error("Error al obtener tareas:", error);
    }
}

// ELIMINAR TAREA
async function deleteTask(id) {
    try {
        await fetch(`http://localhost:3000/api/tasks/${id}`, {
            method: "DELETE",
            headers: { "Authorization": "Bearer " + token }
        });

        getTasks();
    } catch (error) {
        console.error("Error al eliminar tarea:", error);
    }
}
