const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();

const taskRoutes = require('./routes/task.routes');
const authRoutes = require('./routes/auth.routes');

const app = express(); 

app.use(express.json());

const cors = require("cors");
app.use(cors());

// RUTAS
app.use('/api/auth', authRoutes);   // login/register
app.use('/api/tasks', taskRoutes);  // tareas protegidas

// CONEXIÓN A MONGO
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('Base de datos conectada'))
  .catch(err => console.log(err));

// INICIAR SERVIDOR
app.listen(3000, () => {
  console.log('Servidor funcionando en http://localhost:3000');
});
console.log('MONGO_URI:', process.env.MONGO_URI);
