const Task = require('../models/Task');

const createTask = async (req, res) => {
  console.log("REQ.USER:", req.user); // Verificamos que llegue el userId

  try {
    const { title, description, status, due_date } = req.body;

    const task = new Task({
      title,
      description,
      status,
      due_date,
      user: req.user.userId
    });

    await task.save();

    res.json({ message: 'Tarea creada', task });
  } catch (error) {
    console.log("ERROR AL CREAR TAREA:", error);
    res.status(500).json({ error: 'Error al crear la tarea' });
  }
};

const getTasks = async (req, res) => {
  try {
    const tasks = await Task.find({ user: req.user.userId });
    res.json(tasks);
  } catch (error) {
    console.log("ERROR AL OBTENER TAREAS:", error);
    res.status(500).json({ error: 'Error al obtener tareas' });
  }
};

const updateTask = async (req, res) => {
  try {
    const { id } = req.params;

    const updatedTask = await Task.findOneAndUpdate(
      { _id: id, user: req.user.userId },
      req.body,
      { new: true }
    );

    if (!updatedTask) {
      return res.status(404).json({ error: 'Tarea no encontrada' });
    }

    res.json({ message: 'Tarea actualizada', task: updatedTask });
  } catch (error) {
    console.log("ERROR AL ACTUALIZAR TAREA:", error);
    res.status(500).json({ error: 'Error al actualizar la tarea' });
  }
};

const deleteTask = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedTask = await Task.findOneAndDelete({
      _id: id,
      user: req.user.userId
    });

    if (!deletedTask) {
      return res.status(404).json({ error: 'Tarea no encontrada' });
    }

    res.json({ message: 'Tarea eliminada' });
  } catch (error) {
    console.log("ERROR AL ELIMINAR TAREA:", error);
    res.status(500).json({ error: 'Error al eliminar la tarea' });
  }
};

module.exports = { createTask, getTasks, updateTask, deleteTask };
