const jwt = require('jsonwebtoken');

const verifyToken = (req, res, next) => {
  const token = req.header('Authorization');

  if (!token) {
    return res.status(401).json({ error: 'Acceso denegado. Token requerido.' });
  }

  try {
  const verified = jwt.verify(token.replace('Bearer ', ''), process.env.JWT_SECRET);
  console.log("TOKEN DECODIFICADO:", verified); // <-- AGREGA ESTO
  req.user = verified;
  next();
}
 catch (error) {
    res.status(400).json({ error: 'Token inválido.' });
  }
};

module.exports = verifyToken;
