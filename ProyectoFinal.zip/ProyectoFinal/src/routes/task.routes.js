const express = require('express');
const router = express.Router();
const verifyToken = require('../middlewares/auth.middleware');
const { createTask, getTasks, updateTask, deleteTask } = require('../controllers/task.controller');

router.post('/', verifyToken, createTask);

router.get('/', verifyToken, getTasks);

router.put('/:id', verifyToken, updateTask);

router.delete('/:id', verifyToken, deleteTask);

module.exports = router;
